﻿
This project is focused on implementing Interfaces and Inheritance. 

All the information you need about the classes and interfaces can be found in the
testmethods in Tests.Mammals.Basic/Advanced.