﻿This project does not require you to create any Inheritance or Interfaces. 

Create the Classes needed with the information given in the Tests.SubwayGame.Basic/Advanced-folders.

Not all classes are needed in the basic tests for this project.

For the Advanced part of the project, the idea is to check whether the amount of trains
in the same location (City) exceed the amount of tracks in that city. If they do, they crash.